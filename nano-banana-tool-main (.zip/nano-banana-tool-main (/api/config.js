export default function handler(req, res) {
  // Only GET requests are allowed
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Return to Supabase configuration (these are public anon keys, relatively safe)
  const config = {
    supabaseUrl: process.env.SUPABASE_URL,
    supabaseAnonKey: process.env.SUPABASE_ANON_KEY,
    googleClientId: process.env.GOOGLE_CLIENT_ID
  };

  // Check whether the necessary configuration exists
  if (!config.supabaseUrl || !config.supabaseAnonKey) {
    return res.status(500).json({
      error: 'Supabase configuration not found',
      message: 'Please check your environment variables'
    });
  }

  // Return to configuration information
  res.status(200).json(config);
}