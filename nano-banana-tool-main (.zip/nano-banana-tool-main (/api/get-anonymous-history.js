// Get anonymous user history API
export default async function handler(req, res) {
    // Set CORS header
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Process pre-flight request
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    // Only GET requests are allowed
    if (req.method !== 'GET') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    // Check environment variables
    if (!process.env.SUPABASE_URL || (!process.env.SUPABASE_SERVICE_ROLE_KEY && !process.env.SUPABASE_ANON_KEY)) {
        return res.status(500).json({
            error: 'Server configuration error',
            message: 'Supabase configuration not found'
        });
    }

    // Dynamic import of Supabase client
    let supabase;
    try {
        const { createClient } = await import('@supabase/supabase-js');
        const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
        supabase = createClient(process.env.SUPABASE_URL, supabaseKey);
    } catch (error) {
        return res.status(500).json({
            error: 'Database connection failed',
            message: error.message
        });
    }

    try {
        // Get query parameters
        const {
            page = 1,
            limit = 20,
            type = '',
            search = ''
        } = req.query;

        const pageSize = Math.min(parseInt(limit), 100);
        const offset = (parseInt(page) - 1) * pageSize;

        console.log('Query anonymous user history:', { page, limit, type, search });

        // Build query - only query records with user_id NULL
        let query = supabase
            .from('history')
            .select('*')
            .is('user_id', null)
            .order('created_at', { ascending: false });

        // Add filter conditions
        if (type) {
            query = query.eq('type', type);
        }

        if (search) {
            query = query.ilike('prompt', `%${search}%`);
        }

        // Add paging
        query = query.range(offset, offset + pageSize - 1);

        const { data: historyData, error: historyError } = await query;

        if (historyError) {
            console.error('Failed to query anonymous user history:', historyError);
            return res.status(500).json({
                error: 'Database query failed',
                message: historyError.message
            });
        }

        // Get the total number
        let countQuery = supabase
            .from('history')
            .select('*', { count: 'exact', head: true })
            .is('user_id', null);

        if (type) {
            countQuery = countQuery.eq('type', type);
        }

        if (search) {
            countQuery = countQuery.ilike('prompt', `%${search}%`);
        }

        const { count: totalCount, error: countError } = await countQuery;

        if (countError) {
            console.error('Failed to get the total number of anonymous user history:', countError);
        }

        // Process data format
        const processedData = (historyData || []).map(item => ({
            id: item.id,
            user_id: null,
            user_name: 'Anonymous user',
            user_email: 'Not logged in',
            user_avatar: null,
            type: item.type,
            prompt: item.prompt,
            result_image: item.result_image,
            input_images: item.input_images,
            created_at: item.created_at
        }));

        console.log('Query successful, return the number of anonymous user records:', processedData.length);

        return res.status(200).json({
            data: processedData,
            success: true,
            pagination: {
                page: parseInt(page),
                limit: pageSize,
                total: totalCount || 0,
                pages: Math.ceil((totalCount || 0) / pageSize)
            }
        });

    } catch (error) {
        console.error('API handles exception:', error);
        return res.status(500).json({
            error: 'Internal server error',
            message: error.message
        });
    }
}