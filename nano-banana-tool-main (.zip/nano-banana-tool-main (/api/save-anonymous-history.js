// Anonymous user history saving API
export default async function handler(req, res) {
    // Set CORS header
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Process pre-flight request
    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    // Only POST methods are allowed
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    // Check environment variables
    if (!process.env.SUPABASE_URL || (!process.env.SUPABASE_SERVICE_ROLE_KEY && !process.env.SUPABASE_ANON_KEY)) {
        return res.status(500).json({
            error: 'Server configuration error',
            message: 'Supabase configuration not found'
        });
    }

    // Dynamic import of Supabase client
    let supabase;
    try {
        const { createClient } = await import('@supabase/supabase-js');
        const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
        supabase = createClient(process.env.SUPABASE_URL, supabaseKey);
    } catch (error) {
        return res.status(500).json({
            error: 'Database connection failed',
            message: error.message
        });
    }

    try {
        const { type, prompt, result_image, input_images } = req.body;
        
        // Verify required fields
        if (!type || !prompt || !result_image) {
            return res.status(400).json({
                error: 'Missing required fields',
                message: 'type, prompt, and result_image are required'
            });
        }

        console.log('Save anonymous user history:', { type, prompt: prompt.substring(0, 50) + '...' });

        // Insert anonymous user history (user_id is NULL)
        const { data: insertData, error: insertError } = await supabase
            .from('history')
            .insert({
                user_id: null, // Anonymous user uses NULL
                type,
                prompt,
                result_image,
                input_images: input_images || null,
                created_at: new Date().toISOString()
            })
            .select();

        if (insertError) {
            console.error('Failed to save anonymous user history:', insertError);
            return res.status(500).json({
                error: 'Failed to save anonymous history',
                message: insertError.message
            });
        }

        console.log('Anonymous user history saved successfully');
        return res.status(201).json({
            data: insertData && insertData[0] ? insertData[0] : null,
            success: true
        });

    } catch (error) {
        console.error('Anonymous user history save exception:', error);
        return res.status(500).json({
            error: 'Internal server error',
            message: error.message
        });
    }
}