// Administrator history viewing API - Support display of all user data
export default async function handler(req, res) {
  console.log('==== admin-history API starts processing ===');
  console.log('request method:', req.method);
  console.log('request header:', req.headers);

  // Set CORS header
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Process pre-flight request
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Only GET requests are allowed
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Check environment variables
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return res.status(500).json({
      error: 'Server configuration error',
      message: 'Supabase configuration not found'
    });
  }

  // Dynamic import of Supabase client
  let supabase;
  try {
    const { createClient } = await import('@supabase/supabase-js');
    supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    console.log('Supabase client created successfully');
  } catch (error) {
    console.error('Supabase client initialization failed:', error);
    return res.status(500).json({
      error: 'Database connection failed',
      message: error.message
    });
  }

  try {
    // Get query parameters
    const {
      page = 1,
      limit = 50,
      type = '',
      search = '',
      include_anonymous = 'true',
      user_id = ''
    } = req.query;

    const pageSize = Math.min(parseInt(limit), 100); // Maximum 100 items
    const offset = (parseInt(page) - 1) * pageSize;

    console.log('Query parameters:', { page, limit, type, search, include_anonymous, user_id });

    // Build query
    let query = supabase
      .from('history')
      .select(`
        id,
        user_id,
        type,
        prompt,
        result_image,
        input_images,
        created_at,
        users!inner(
          id,
          email,
          name,
          avatar_url
        )
      `)
      .order('created_at', { ascending: false });

    // Add filter conditions
    if (type) {
      query = query.eq('type', type);
    }

    if (user_id) {
      query = query.eq('user_id', user_id);
    }

    if (search) {
      query = query.ilike('prompt', `%${search}%`);
    }

    // Handle anonymous users
    if (include_anonymous === 'false') {
      // Only display logged-in users
      query = query.not('user_id', 'is', null);
    }

    // Add paging
    query = query.range(offset, offset + pageSize - 1);

    console.log('Execute query...');
    const { data: historyData, error: historyError, count } = await query;

    if (historyError) {
      console.error('Query failed:', historyError);
      return res.status(500).json({
        error: 'Database query failed',
        message: historyError.message
      });
    }

    // Get the total number
    let countQuery = supabase
      .from('history')
      .select('*', { count: 'exact', head: true });

    if (type) {
      countQuery = countQuery.eq('type', type);
    }

    if (user_id) {
      countQuery = countQuery.eq('user_id', user_id);
    }

    if (search) {
      countQuery = countQuery.ilike('prompt', `%${search}%`);
    }

    if (include_anonymous === 'false') {
      countQuery = countQuery.not('user_id', 'is', null);
    }

    const { count: totalCount, error: countError } = await countQuery;

    if (countError) {
      console.error('Failed to get total number:', countError);
    }

    // Process data format
    const processedData = (historyData || []).map(item => {
      const user = item.users || {};
      return {
        id: item.id,
        user_id: item.user_id,
        user_name: user.name || user.email || 'Anonymous user',
        user_email: user.email || 'Not logged in',
        user_avatar: user.avatar_url || null,
        type: item.type,
        prompt: item.prompt,
        result_image: item.result_image,
        input_images: item.input_images,
        created_at: item.created_at,
        // Add URL field - Image data is in base64 format, directly use
        result_image_url: item.result_image || null,
        input_image_urls: item.input_images?
          (Array.isArray(item.input_images) ?
            item.input_images:
            [item.input_images]
          ) : []
      };
    });

    console.log('Query successful, return the number of data strips:', processedData.length);

    return res.status(200).json({
      success: true,
      data: processedData,
      pagination: {
        page: parseInt(page),
        limit: pageSize,
        total: totalCount || 0,
        pages: Math.ceil((totalCount || 0) / pageSize)
      },
      filters: {
        type,
        search,
        include_anonymous: include_anonymous === 'true',
        user_id
      }
    });

  } catch (error) {
    console.error('API handles exception:', error);
    return res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
}