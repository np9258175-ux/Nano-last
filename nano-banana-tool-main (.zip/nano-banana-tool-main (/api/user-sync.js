// User synchronization API endpoint
export default async function handler(req, res) {
  // Set CORS header
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, user-id');

  // Process pre-flight request
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Only POST methods are allowed
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

           // Check environment variables
         if (!process.env.SUPABASE_URL || (!process.env.SUPABASE_SERVICE_ROLE_KEY && !process.env.SUPABASE_ANON_KEY)) {
           console.error('Supabase configuration is missing');
           return res.status(500).json({
             error: 'Server configuration error',
             message: 'Supabase configuration not found'
           });
         }

          // Dynamic import of Supabase client
        let supabase;
        try {
          const { createClient } = await import('@supabase/supabase-js');
          supabase = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY
          );
        } catch (error) {
          console.error('Supabase client initialization failed:', error);
          return res.status(500).json({
            error: 'Database connection failed',
            message: error.message
          });
        }

  try {
    const { user_id, email, name, avatar_url } = req.body;

    // Verify required fields
    if (!user_id || !email) {
      return res.status(400).json({
        error: 'Missing required fields',
        message: 'user_id and email are required'
      });
    }

    console.log('Sync user information:', { user_id, email, name });

    // Synchronize user information to the users table
    console.log('Start the Supabase upsert operation...');
    const { data: userData, error: userError } = await supabase
      .from('users')
      .upsert({
        id: user_id,
        email: email,
        name: name || email.split('@')[0],
        avatar_url: avatar_url || null,
        created_at: new Date().toISOString()
      }, {
        onConflict: 'id'
      })
      .select();

    console.log('Supabase response:', { userData, userError });

    if (userError) {
      console.error('User synchronization failed:', userError);
      console.error('Error details:', {
        message: userError.message,
        details: userError.details,
        hint: userError.hint,
        code: userError.code
      });
      return res.status(500).json({
        error: 'Failed to sync user',
        message: userError.message,
        details: userError.details,
        hint: userError.hint,
        code: userError.code
      });
    }

    console.log('User information synchronization is successful');
    return res.status(200).json({
      data: userData && userData[0] ? userData[0] : null,
      success: true
    });

  } catch (error) {
    console.error('User synchronization exception:', error);
    return res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
}