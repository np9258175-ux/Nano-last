// Script to fix history loading issues
// Main problem: Supabase query returns 500 error

const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Create a fixed user history API
function createFixedUserHistoryAPI() {
  return async function handler(req, res) {
    // Set CORS header
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, user-id');

    // Process pre-flight request
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }

    // Check environment variables
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
      console.error('Supabase configuration is missing');
      return res.status(500).json({
        error: 'Server configuration error',
        message: 'Supabase configuration not found'
      });
    }

    // Dynamic import of Supabase client
    let supabase;
    try {
      const { createClient } = await import('@supabase/supabase-js');
      supabase = createClient(
        process.env.SUPABASE_URL,
        process.env.SUPABASE_ANON_KEY
      );
    } catch (error) {
      console.error('Supabase client initialization failed:', error);
      return res.status(500).json({
        error: 'Database connection failed',
        message: error.message
      });
    }

    try {
      const { method } = req;
      const userId = req.headers['user-id'] || req.body?.user_id;

      // Verify user ID
      if (!userId) {
        return res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required in headers or body'
        });
      }

      console.log('Processing request:', { method, userId });

      switch (method) {
        case 'GET':
          // Get user history - Fixed version
          try {
            console.log('Start query history, user ID:', userId);
            
            // Add error handling and retry mechanism
            let retryCount = 0;
            const maxRetries = 3;
            let lastError;

            while (retryCount < maxRetries) {
              try {
                const { data: historyData, error: historyError } = await supabase
                  .from('history')
                  .select('*')
                  .eq('user_id', userId)
                  .order('created_at', { ascending: false })
                  .limit(100); // Limit the number of results

                if (historyError) {
                  console.error(`${retryCount + 1} query failed:`, historyError);
                  lastError = historyError;
                  retryCount++;
                  
                  if (retryCount < maxRetries) {
                    console.log(`Wait 1 second before trying again...`);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    continue;
                  }
                } else {
                  console.log('Query successful, return the number of data strips:', historyData?.length || 0);
                  return res.status(200).json({
                    data: historyData || [],
                    success: true
                  });
                }
              } catch (queryError) {
                console.error(`Query exception (${retryCount + 1}):`, queryError);
                lastError = queryError;
                retryCount++;
                
                if (retryCount < maxRetries) {
                  console.log(`Wait 1 second before trying again...`);
                  await new Promise(resolve => setTimeout(resolve, 1000));
                  continue;
                }
              }
            }

           // All retry failed
            console.error('All retry failed, last error:', lastError);
            return res.status(500).json({
              error: 'Database query failed after retries',
              message: lastError?.message || 'Unknown error'
            });

          } catch (error) {
            console.error('History query exception:', error);
            return res.status(500).json({
              error: 'Internal server error',
              message: error.message
            });
          }

        case 'POST':
          // Add history - Fixed version
          try {
            const { type, prompt, result_image, input_images } = req.body;
            
            if (!type || !prompt || !result_image) {
              return res.status(400).json({
                error: 'Missing required fields',
                message: 'type, prompt, and result_image are required'
              });
            }

            console.log('Prepare to insert history:', { type, prompt, userId });

            const { data: insertData, error: insertError } = await supabase
              .from('history')
              .insert({
                user_id: userId,
                type,
                prompt,
                result_image,
                input_images: input_images || null,
                created_at: new Date().toISOString()
              })
              .select();

            if (insertError) {
              console.error('Insert history failed:', insertError);
              return res.status(500).json({
                error: 'Failed to save history',
                message: insertError.message
              });
            }

            console.log('History insertion successful');
            return res.status(201).json({
              data: insertData,
              success: true
            });

          } catch (error) {
            console.error('Insert history exception:', error);
            return res.status(500).json({
              error: 'Internal server error',
              message: error.message
            });
          }

        case 'DELETE':
          // Delete history - Fixed version
          try {
            const { id } = req.query;
            
            if (!id) {
              return res.status(400).json({
                error: 'Missing ID',
                message: 'History item ID is required'
              });
            }

            console.log('Prepare to delete history:', { id, userId });

            // Verification record belongs to the current user
            const { data: existingRecord, error: checkError } = await supabase
              .from('history')
              .select('user_id')
              .eq('id', id)
              .single();

            if (checkError) {
              console.error('Check record ownership failed:', checkError);
              return res.status(500).json({
                error: 'Failed to verify record ownership',
                message: checkError.message
              });
            }

            if (!existingRecord || existingRecord.user_id !== userId) {
              return res.status(403).json({
                error: 'Unauthorized',
                message: 'Cannot delete this record'
              });
            }

            const { error: deleteError } = await supabase
              .from('history')
              .delete()
              .eq('id', id);

            if (deleteError) {
              console.error('Delete history failed:', deleteError);
              return res.status(500).json({
                error: 'Failed to delete record',
                message: deleteError.message
              });
            }

            console.log('History record deletion successfully');
            return res.status(200).json({
              message: 'Record deleted successfully',
              success: true
            });

          } catch (error) {
            console.error('Delete history exception:', error);
            return res.status(500).json({
              error: 'Internal server error',
              message: error.message
            });
          }

        default:
          res.setHeader('Allow', ['GET', 'POST', 'DELETE']);
          return res.status(405).json({ error: 'Method not allowed' });
      }
    } catch (error) {
      console.error('API Handle exceptions:', error);
      return res.status(500).json({
        error: 'Internal server error',
        message: error.message
      });
    }
  };
}
//Create a repaired clear history API
function createFixedClearHistoryAPI() {
  return async function handler(req, res) {
    // Set CORS header
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, user-id');

// Process pre-flight request
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }

    //Only DELETE methods are allowed
    if (req.method !== 'DELETE') {
      return res.status(405).json({ error: 'Method not allowed' });
    }

  // Check environment variables
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
      console.error('Supabase Configuration missing');
      return res.status(500).json({
        error: 'Server configuration error',
        message: 'Supabase configuration not found'
      });
    }

    // Dynamic import of Supabase client
    let supabase;
    try {
      const { createClient } = await import('@supabase/supabase-js');
      supabase = createClient(
        process.env.SUPABASE_URL,
        process.env.SUPABASE_ANON_KEY
      );
    } catch (error) {
      console.error('Supabase client initialization failed:', error);
      return res.status(500).json({
        error: 'Database connection failed',
        message: error.message
      });
    }

    try {
      const userId = req.headers['user-id'] || req.body?.user_id;

      if (!userId) {
        return res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required'
        });
      }

      console.log('Prepare to clear user history:', userId);

      // Delete all user's history
      const { error: deleteError } = await supabase
        .from('history')
        .delete()
        .eq('user_id', userId);

if (deleteError) {
        console.error('Clear history failed:', deleteError);
        return res.status(500).json({
          error: 'Failed to clear history',
          message: deleteError.message
        });
      }

      console.log('History cleared successfully');
      return res.status(200).json({
        message: 'All history records cleared successfully',
        success: true
      });

    } catch (error) {
      console.error('Clear history exception:', error);
      return res.status(500).json({
        error: 'Internal server error',
        message: error.message
      });
    }
  };
}

module.exports = {
  createFixedUserHistoryAPI,
  createFixedClearHistoryAPI
};